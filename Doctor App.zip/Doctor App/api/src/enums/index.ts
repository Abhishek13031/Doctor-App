export enum BloodGroup {
    'O+',  'O-' , 'B+' , 'B-' , 'AB+' , 'AB-' , 'A+' , 'A-'
}